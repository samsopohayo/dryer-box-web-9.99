#ifndef OFFLINESTORAGE_H
#define OFFLINESTORAGE_H

#include "../globals.h"

class OfflineStorage {
public:
  static void save();
  static void sync();
};

#endif 