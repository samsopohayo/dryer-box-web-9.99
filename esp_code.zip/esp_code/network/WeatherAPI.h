#ifndef WEATHERAPI_H
#define WEATHERAPI_H

#include "../globals.h"

class WeatherAPI {
public:
  static void fetchWeather();
};

#endif 