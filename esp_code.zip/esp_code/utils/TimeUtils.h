#ifndef TIMEUTILS_H
#define TIMEUTILS_H

#include 
#include 

class TimeUtils {
public:
  static String getTimestamp();
  static String generateSessionId();
};

#endif 