#ifndef CALCULATIONS_H
#define CALCULATIONS_H

#include 

class Calculations {
public:
  static float calculateMoistureContent(float currentWeight, float initialWeight);
};

#endif 