declare module "chartjs-plugin-zoom";
