declare module "lucide-vue-next";
